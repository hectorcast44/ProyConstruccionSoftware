<?php

namespace App\Exceptions;

use Exception;

class ActividadException extends Exception
{
    // Personalizar si es necesario
}
