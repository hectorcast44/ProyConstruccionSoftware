<?php

namespace App\Exceptions;

use Exception;

class MateriaException extends Exception
{
    // Personalizar si es necesario
}
