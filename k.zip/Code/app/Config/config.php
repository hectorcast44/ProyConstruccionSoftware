<?php

return [
    'db' => [
        'host' => 'localhost',
        'name' => 'agenda_escolar',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4'
    ]
];
